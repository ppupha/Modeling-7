# Modeling
IU7, 7 semester, course of modeling
