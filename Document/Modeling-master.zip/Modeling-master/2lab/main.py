from view import View


def main():
    view = View()
    view.start_application()


if __name__ == '__main__':
    main()
